const global = {
  owner: [8576790003],
  botToken: process.env.HEXONE_BOT_TOKEN || '8983691357:AAHOCklktFn90snsU_NVDQpjrkREZg2n5_o',
};

module.exports = global;
