/*!
 * ghost.js — GHOST v2.0 "ADAPTIF"  ·  behavioral self-learning bypasser
 * =====================================================================
 * SATU FILE, MURNI JS, tanpa dependency. Aman untuk Termux.
 *
 * Pemakaian:
 *     node -r ./ghost.js target.js
 * atau di package.json:
 *     "start": "node -r ./ghost.js target.js"
 *
 * FILOSOFI v2 (beda dengan v1):
 *   V1 masih punya kamus (lexicon penolakan, daftar nama flag, daftar nama
 *   field) = "tool sudah tahu duluan". V2 MEMBUANG SEMUA KAMUS. Tidak ada
 *   satu pun kata/nama/field/host yang diprediksi sebelumnya. Yang ada:
 *
 *   1) ORACLE PRILAKU — tool tidak perlu tahu apa itu "ditolak":
 *        - client MENGULANG request yang sama          = jawaban belum lolos
 *        - client BERHENTI mengulang (lalu lanjut)     = jawaban diterima
 *        - client mati / bunuh diri                    = ditolak keras
 *      Keputusan hanya dari sinyal ini, bukan dari isi kata respons.
 *
 *   2) SUNTIK TERUS SAMPAI VALID — tangga varian MUTASI STRUKTURAL
 *      (bukan semantik), diuji BERURUTAN, umpan balik memilih pemenang:
 *        v1  status -> 200 (HTTP spec)
 *        v2  + semua boolean false -> true (rekursif, bebas nama)
 *        v3  + buang string "berbentuk kode" (bentuk struktural: pendek,
 *              satu-token, bukan tanggal/bukan kandidat — BUKAN kamus kata)
 *        v4  + rekaman reflektif: isi array dengan record yang skemanya
 *              DICERMIN dari data client sendiri (key request + memori skema
 *              proses + sample object respons) dan nilainya kandidat identitas
 *        v5  + substitusi string kode-kodean dengan kandidat identitas
 *        v6  + suntik dalam: array diisi kandidat, string kosong diisi kandidat
 *        v7+ varian BERBIBIT: rotasi urutan kandidat per putaran — varian
 *            baru terus terbit setiap client nge-retry. Adaptasi tanpa batas.
 *      Kandidat identitas = string yang CLIENT KIRIM SENDIRI (refleksi) +
 *      basket hash umum (ruang coba yang diuji, bukan asumsi).
 *
 *   3) JEJAK MINIMAL (prioritas utama):
 *        - SENYAP TOTAL by default: nol baris output konsol.
 *        - env GHOST_* dihapus dari process.env setelah dibaca.
 *        - module MENGHAPUS DIRINYA: require.cache + pohon require.main.
 *        - jejak execArgv (bekas -r) dibersihkan.
 *        - permukaan patch minim: fetch (Proxy transparan), axios (API
 *          resmi), node-fetch kalau ada. Observasi http/https hanya saat
 *          GHOST_DEBUG aktif (default: TIDAK dipatch sama sekali).
 *        - semua fungsi pasangan mempertahankan bentuk native (toString).
 *        - state di Symbol registry (tak terlihat enumerasi global).
 *
 *   4) DETERMINISTIK — jawaban yang diterima client dibekukan byte-identik
 *      per fingerprint request (axios dan fetch melihat persis sama).
 *
 * KNOB (dibaca lalu DIHAPUS dari env):
 *   GHOST_DEBUG=<file>    log detail ke file (satu-satunya cara melihat kerjanya)
 *   GHOST_VERBOSE=1       log ke konsol juga (meninggalkan jejak — tidak disarankan)
 *   GHOST_HOLD=1          bekukan exit(code>0) — proses jadi zombie
 *   GHOST_NOSURVIVAL=1    matikan fake self-kill
 *   GHOST_NO_TOSTR=1      matikan kamuflase Function.prototype.toString
 *   GHOST_ESCALATE_MS=1200  ambang "client nge-retry"
 *   GHOST_LOCK_MS=8000      ambang "client lolos"
 */

'use strict';

(function GHOST_BOOT() {

/* ===== penjaga muat-ulang: global symbol registry (tak terlihat enum) ===== */
try {
    if (globalThis[Symbol.for('ghost.v2')]) return;
    globalThis[Symbol.for('ghost.v2')] = true;
} catch (e) {}

/* ======================= knobs + bersih-bersih env ======================= */

let envVals = {};
try {
    for (const k of Object.keys(process.env)) {
        if (k.lastIndexOf('GHOST_', 0) === 0) { envVals[k] = process.env[k]; }
    }
    for (const k of Object.keys(envVals)) { try { delete process.env[k]; } catch (e) {} }
} catch (e) { envVals = process.env || {}; }

const on = (v) => /^(1|true|yes)$/i.test(String(v == null ? '' : v));
const VERBOSE = on(envVals.GHOST_VERBOSE);
const DEBUG_PATH = envVals.GHOST_DEBUG || '';
const HOLD_EXIT = on(envVals.GHOST_HOLD);
const NO_SURVIVAL = on(envVals.GHOST_NOSURVIVAL);
const NO_TOSTR = on(envVals.GHOST_NO_TOSTR);
const ESCALATE_MS = Math.max(300, Number(envVals.GHOST_ESCALATE_MS || 1200));
const LOCK_MS = Math.max(1000, Number(envVals.GHOST_LOCK_MS || 8000));
const FIXED_TS = '2020-01-01T00:00:00.000Z';   // deterministik, netral
const BASE_STEPS = 10;                          // varian dasar; setelahnya varian berbibit

/* ================================ logger ================================= */
/* Default: SENYAP TOTAL. GHOST_DEBUG=file -> log file async (jejak minimal). */

const fs = require('fs');
function say() {
    if (!VERBOSE) return;
    try { console.log('[ghost]', Array.prototype.join.call(arguments, ' ')); } catch (e) {}
}
function dbg() {
    if (!DEBUG_PATH) return;
    try {
        fs.appendFile(DEBUG_PATH, new Date().toISOString() + ' ' +
            Array.prototype.join.call(arguments, ' ') + '\n', () => {});
    } catch (e) { /* jangan pernah melempar dari hook */ }
}

/* ============= higienis vektor: bersihkan jejak execArgv ================= */

try {
    if (Array.isArray(process.execArgv) && process.execArgv.length) {
        dbg('execArgv dibersihkan:', process.execArgv.join(' '));
        process.execArgv = [];
    }
} catch (e) {}

/* ====================== kamuflase bentuk native ========================== */

const realFnToString = Function.prototype.toString;
const NATIVE_MAP = new Map();
if (!NO_TOSTR) {
    const patchedToString = function toString() {
        try {
            const s = NATIVE_MAP.get(this);
            if (s) return s;
        } catch (e) {}
        return realFnToString.call(this);
    };
    NATIVE_MAP.set(patchedToString, 'function toString() { [native code] }');
    try { Function.prototype.toString = patchedToString; } catch (e) {}
}
function disguise(fn, name) {
    try {
        if (name) Object.defineProperty(fn, 'name', { value: name, configurable: true });
        Object.defineProperty(fn, 'toString', {
            value: function () { return 'function ' + (name || '') + '() { [native code] }'; },
            writable: true, configurable: true,
        });
        NATIVE_MAP.set(fn, 'function ' + (name || '') + '() { [native code] }');
    } catch (e) {}
    return fn;
}

/* ============================ util dasar ================================= */

const crypto = require('crypto');
function h(alg, s) {
    try { return crypto.createHash(alg).update(String(s)).digest('hex'); }
    catch (e) { return ''; }
}
function isObj(x) { return x && typeof x === 'object' && !Array.isArray(x); }
function parseMaybe(x) {
    if (isObj(x)) return x;
    if (typeof x === 'string') { try { return JSON.parse(x); } catch (e) { return null; } }
    return null;
}
function cloneJson(x) { try { return JSON.parse(JSON.stringify(isObj(x) ? x : {})); } catch (e) { return {}; } }

/* ================= refleksi: kandidat identitas & memori ================= */
/* Kandidat = string yang PROSES ITU SENDIRI kirim (body/query/header).
 * Tidak ada bentuk khusus, tidak ada nama kunci — murni cermin prilaku. */

function pushCand(out, seen, v) {
    if (typeof v !== 'string' || v.length < 8 || v.length > 200) return;
    if (/^\s|\s$/.test(v)) return;
    if (seen.has(v)) return;
    seen.add(v); out.push(v);
}
function walkCands(o, depth, out, seen) {
    if (!o || typeof o !== 'object' || depth > 3) return;
    for (const k of Object.keys(o)) {
        const v = o[k];
        if (typeof v === 'string') pushCand(out, seen, v);
        else if (v && typeof v === 'object') walkCands(v, depth + 1, out, seen);
    }
}
function candidatesFrom(body, url, headers) {
    const out = [], seen = new Set();
    if (isObj(body)) walkCands(body, 0, out, seen);
    else {
        let s = null;
        if (typeof body === 'string') s = body;
        else if (Buffer.isBuffer(body)) { try { s = body.toString('utf8'); } catch (e) {} }
        if (s) {
            const obj = parseMaybe(s);
            if (obj) walkCands(obj, 0, out, seen);
            if (!out.length) {
                try { for (const [, v] of new URLSearchParams(s)) pushCand(out, seen, v); } catch (e) {}
            }
        }
    }
    try {
        const u = new URL(url, 'http://x.invalid');
        for (const [, v] of u.searchParams) pushCand(out, seen, v);
    } catch (e) {}
    try {
        if (headers && typeof headers.forEach === 'function') {
            headers.forEach((v, k) => {
                const kl = String(k).toLowerCase();
                if (kl === 'authorization' || kl === 'x-api-key' || kl === 'x-auth' ||
                    kl === 'x-token' || kl === 'x-key' || kl === 'cookie') {
                    const val = String(v).replace(/^(bearer|basic|token)\s+/i, '').trim();
                    if (val) pushCand(out, seen, val);
                }
            });
        } else if (headers && typeof headers === 'object') {
            for (const k of Object.keys(headers)) {
                const kl = String(k).toLowerCase();
                if (kl === 'authorization' || kl === 'x-api-key' || kl === 'x-auth' ||
                    kl === 'x-token' || kl === 'x-key' || kl === 'cookie') {
                    let v = headers[k];
                    if (v && typeof v !== 'string') v = String(v);
                    if (typeof v !== 'string') continue;
                    const val = v.replace(/^(bearer|basic|token)\s+/i, '').trim();
                    if (val) pushCand(out, seen, val);
                }
            }
        }
    } catch (e) {}
    return out.slice(0, 6);
}
function bodyKeys(body) {
    const out = [];
    try {
        const o = isObj(body) ? body : parseMaybe(typeof body === 'string' || Buffer.isBuffer(body) ? String(body) : null);
        if (isObj(o)) for (const k of Object.keys(o)) out.push(k);
    } catch (e) {}
    return out.slice(0, 24);
}

/* Memori skema: SEMUA key JSON yang pernah lewat proses (prilaku nyata),
 * dipakai untuk mencerminkan bentuk record saat menyuntik. Dibatasi ukuran. */
const schemaMemory = new Set();
function rememberKeys(o) {
    try {
        if (!o || typeof o !== 'object' || schemaMemory.size > 512) return;
        (function w(x, d) {
            if (!x || typeof x !== 'object' || d > 2 || schemaMemory.size > 512) return;
            for (const k of Object.keys(x)) {
                if (schemaMemory.size > 512) return;
                schemaMemory.add(k);
                const v = x[k];
                if (v && typeof v === 'object') w(v, d + 1);
            }
        })(o, 0);
    } catch (e) {}
}

/* ================== oracle: klasifikasi berbasis struktur ================ */
/* "Penolakan" versi bebas-kamus: status HTTP >= 400, ATAU ada boolean false
 * di badan respons. Tidak ada daftar kata, tidak ada nama flag. */

function hasFalseBoolean(o, d) {
    if (!o || typeof o !== 'object' || d > 3) return false;
    for (const k of Object.keys(o)) {
        const v = o[k];
        if (v === false) return true;
        if (v && typeof v === 'object' && hasFalseBoolean(v, d + 1)) return true;
    }
    return false;
}
function classifyFailure(status, data) {
    if (typeof status === 'number' && status >= 400) return true;
    return hasFalseBoolean(data, 0);
}

/* =================== mutasi struktural (bebas kamus) ===================== */

function flipBooleans(o, d) {
    if (!o || typeof o !== 'object' || d > 4) return o;
    for (const k of Object.keys(o)) {
        const v = o[k];
        if (v === false) o[k] = true;
        else if (v && typeof v === 'object') flipBooleans(v, d + 1);
    }
    return o;
}

const CODEISH = /^[a-z0-9_\-]{3,23}$/i;      // bentuk: satu-token pendek
const ISODATE = /^\d{4}-\d{2}-\d{2}/;
function isCodeish(s, cands) {
    if (typeof s !== 'string' || !CODEISH.test(s)) return false;
    if (ISODATE.test(s)) return false;
    if (cands && cands.indexOf(s) !== -1) return false;
    return true;
}
function pruneCodeish(o, cands, d) {
    if (!o || typeof o !== 'object' || d > 3) return;
    for (const k of Object.keys(o)) {
        const v = o[k];
        if (isCodeish(v, cands)) { delete o[k]; continue; }
        if (v && typeof v === 'object') pruneCodeish(v, cands, d + 1);
    }
}
function substituteCodeish(o, cands, seed, d) {
    if (!cands || !cands.length) return;
    if (!o || typeof o !== 'object' || d > 3) return;
    let i = seed;
    for (const k of Object.keys(o)) {
        const v = o[k];
        if (isCodeish(v, cands)) { o[k] = cands[(i++) % cands.length]; continue; }
        if (v && typeof v === 'object') substituteCodeish(v, cands, i, d + 1);
    }
}

/* basket hash: RUANG COBA yang diuji adaptif — bukan asumsi algoritma */
function hashBasket(creds) {
    const out = [], seen = new Set();
    const add = (s) => { if (s && s.length <= 160 && !seen.has(s)) { seen.add(s); out.push(s); } };
    const algs = ['sha256', 'sha1', 'md5', 'sha512'];
    const prefixes = ['', 'sha256:', 'sha256s:', 'sha1:', 'md5:'];
    const c0 = creds[0] || '', c1 = creds[1] || c0;
    const combos = [c0, c1, c0 + c1, c0 + ':' + c1, c1 + ':' + c0, c0 + '|' + c1];
    for (const alg of algs) {
        for (const c of combos) {
            const hx = h(alg, c);
            if (!hx) continue;
            for (const p of prefixes) add(p + hx);
        }
    }
    for (const c of creds) add(c);
    return out.slice(0, 128);
}

function synthesizeLike(sample, cands, basket, i) {
    const rec = {};
    for (const k of Object.keys(sample)) {
        const v = sample[k];
        if (typeof v === 'boolean') rec[k] = true;
        else if (typeof v === 'number') rec[k] = v === 0 ? 0 : v;
        else if (typeof v === 'string') rec[k] = ISODATE.test(v) ? FIXED_TS : basket[i % basket.length];
        else if (v === null) rec[k] = null;
        else rec[k] = v;
    }
    return rec;
}
function synthesizeFree(fields, cands, basket, i) {
    const rec = {};
    let j = 0;
    for (const f of fields) {
        rec[f] = ((i + j) % 2 === 0)
            ? basket[(i + j) % basket.length]
            : cands[(i + j) % cands.length];
        j++;
    }
    return Object.keys(rec).length ? rec : null;
}
function enrichReflective(out, cands, reqKeys, wide) {
    if (!cands.length) return 0;
    const basket = hashBasket(cands);
    if (!basket.length) return 0;
    const fields = [];
    const fseen = new Set();
    for (const k of (reqKeys || [])) if (!fseen.has(k)) { fseen.add(k); fields.push(k); }
    for (const k of schemaMemory) if (!fseen.has(k)) { fseen.add(k); fields.push(k); }
    let n = 0;
    (function fill(o, d) {
        if (!o || typeof o !== 'object' || d > 3) return;
        for (const k of Object.keys(o)) {
            const v = o[k];
            if (Array.isArray(v)) {
                const sample = v.find((x) => isObj(x));
                const recs = [];
                const total = wide ? 24 : 8;
                for (let i = 0; i < total; i++) {
                    const rec = sample ? synthesizeLike(sample, cands, basket, i)
                                       : synthesizeFree(fields, cands, basket, i);
                    if (rec) recs.push(rec);
                }
                if (recs.length) { o[k] = recs.concat(v); n += recs.length; }
            } else if (v && typeof v === 'object') fill(v, d + 1);
        }
    })(out, 0);
    return n;
}
function deepInject(out, cands) {
    const basket = hashBasket(cands);
    if (!basket.length) return 0;
    let i = 0, n = 0;
    (function w(o, d) {
        if (!o || typeof o !== 'object' || d > 3) return;
        for (const k of Object.keys(o)) {
            const v = o[k];
            if (Array.isArray(v)) {
                for (const s of basket.slice(0, 8)) { v.push(s); n++; }
            } else if (v === '' && cands.length) {
                o[k] = cands[(i++) % cands.length]; n++;
            } else if (v && typeof v === 'object') w(v, d + 1);
        }
    })(out, 0);
    return n;
}

/* ================= rencana adaptif per fingerprint request =============== */
/* Oracle-nya murni prilaku: retry = eskalasi varian; diam = kunci & bekukan. */

const plans = new Map();

function bodyHash(body) {
    let s = '';
    try {
        if (typeof body === 'string') s = body;
        else if (Buffer.isBuffer(body)) s = body.toString('utf8');
        else if (body != null) s = JSON.stringify(body);
    } catch (e) {}
    return s ? h('sha256', s).slice(0, 16) : 'nobod';
}
function urlParts(url) {
    try { const u = new URL(url, 'http://x.invalid'); return [u.hostname, u.pathname]; }
    catch (e) { return ['', String(url).slice(0, 120)]; }
}
function planKey(method, url, body) {
    const hp = urlParts(url);
    return String(method || 'get').toUpperCase() + '|' + hp[0] + '|' + hp[1] + '|' + bodyHash(body);
}
function planLabel(method, url) {
    const hp = urlParts(url);
    return String(method || 'get').toUpperCase() + ' ' + hp[0] + hp[1];
}
function getPlan(key, label) {
    let p = plans.get(key);
    if (!p) {
        p = {
            key, label: label || key,
            step: 1, attempts: 0,
            base: null, cands: [], reqKeys: [],
            bytes: null, parsed: null,
            lastServeAt: 0, lockTimer: null, locked: false,
            survivalArmed: false,
        };
        plans.set(key, p);
    }
    return p;
}

/* ===== resep varian: urutan tembakan dari "clean accept" ke makin kaya =====
 * Pelajaran prilaku: banyak target mencetak verdict penolakan TANPA retry
 * (retry cuma terjadi saat konsistensi gagal). Maka tembakan PERTAMA harus
 * yang terkuat yang aman: flip boolean + buang bentuk-kode (bebas nama).
 * Varian kaya (rekaman/suntik) menyusul; putaran berbibit = adaptasi tanpa batas. */
const RECIPES = {
    1:  { flip: 1, prune: 1 },
    2:  { flip: 1, prune: 1, enrich: 1 },
    3:  { flip: 1, prune: 1, subst: 1 },
    4:  { flip: 1, prune: 1, inject: 1 },
    5:  { flip: 1, prune: 1, enrich: 1, subst: 1 },
    6:  { flip: 1, prune: 1, enrich: 1, inject: 1 },
    7:  { flip: 1, prune: 1, subst: 1, inject: 1 },
    8:  { flip: 1, prune: 1, enrich: 1, subst: 1, inject: 1 },
    9:  { flip: 1 },   // tanpa prune (kalau prune justru merusak)
    10: {},            // status saja (badan non-JSON)
};

function buildVariant(plan, step) {
    const base = cloneJson(plan.base);
    const raw = plan.cands || [];
    const cycle = Math.floor((step - 1) / BASE_STEPS);   // putaran bibit
    const s = ((step - 1) % BASE_STEPS) + 1;
    const cands = raw.length
        ? raw.map((_, i) => raw[(i + cycle) % raw.length])
        : raw;
    const r = (cycle >= 1)
        ? { flip: 1, prune: 1, enrich: 1, subst: 1, inject: 1 }   // varian berbibit: resep terkaya, kandidat dirotasi
        : (RECIPES[s] || {});
    let nRec = 0, nInj = 0;
    if (r.flip) flipBooleans(base, 0);
    if (r.prune) pruneCodeish(base, cands, 0);
    if (r.enrich) nRec = enrichReflective(base, cands, plan.reqKeys, s === 8 || cycle >= 1);
    if (r.subst) substituteCodeish(base, cands, seed0(cycle), 0);
    if (r.inject) nInj = deepInject(base, cands);
    dbg('varian v' + step + ' (s' + s + '/putaran' + cycle + ') rec=' + nRec + ' inj=' + nInj);
    return JSON.stringify(base);
}
function seed0(c) { return c || 0; }

/* ===== oracle tambahan berbasis prilaku: proses mencoba mati = ditolak keras.
 * Kalau proses bunuh diri / exit(>0) TEPAT SETELAH jawaban kita "diterima",
 * artinya penerimaan itu palsu -> rencana dibuka ulang & dieskalasi. ===== */
let deathSignalAt = 0;
function reopenLockedPlans() {
    const now = Date.now();
    for (const p of plans.values()) {
        if (p.locked && now - p.lastServeAt < 120000) {
            p.locked = false;
            p.step++;
            p.bytes = null; p.parsed = null;
            dbg('proses coba mati setelah serve — rencana dibuka, eskalasi v' + p.step + ' |', p.label);
        }
    }
}

function planServe(plan) {
    const now = Date.now();
    plan.attempts++;
    const gap = plan.lastServeAt ? (now - plan.lastServeAt) : 0;
    dbg('serve #' + plan.attempts + ' v' + plan.step + ' gap=' + gap + 'ms |', plan.label);
    if (plan.attempts > 1 && gap > ESCALATE_MS) {
        if (plan.locked) { plan.locked = false; say('client kembali — rencana dibuka ulang |', plan.label); }
        plan.step++;
        plan.bytes = null; plan.parsed = null;
        say('client nge-retry — suntik varian baru v' + plan.step + ' |', plan.label);
        if (!plan.survivalArmed && plan.step > BASE_STEPS * 2) {
            plan.survivalArmed = true;
            say('banyak varian ditolak — mode survival aktif |', plan.label);
        }
    }
    if (!plan.bytes) {
        plan.bytes = buildVariant(plan, plan.step);
        try { plan.parsed = JSON.parse(plan.bytes); } catch (e) { plan.parsed = null; }
    }
    plan.lastServeAt = now;
    if (plan.lockTimer) clearTimeout(plan.lockTimer);
    const t = setTimeout(() => {
        // kunci hanya kalau proses TIDAK mencoba mati setelah jawaban disajikan
        if (deathSignalAt >= plan.lastServeAt) { dbg('kunci ditunda — ada sinyal mati setelah serve |', plan.label); return; }
        if (Date.now() - plan.lastServeAt >= LOCK_MS - 100 && !plan.locked) {
            plan.locked = true;
            say('v' + plan.step + ' DIKUNCI — client berhenti nge-retry (lolos) |', plan.label);
        }
    }, LOCK_MS);
    if (t.unref) t.unref();
    plan.lockTimer = t;
    return { bytes: plan.bytes, parsed: plan.parsed };
}

/* ==================== axios layer (API resmi axios) ====================== */

function patchAxiosResp(resp, tag) {
    try {
        const cfg = (resp && resp.config) || {};
        const url = String((cfg.baseURL || '') || '') + String((cfg.url || '') || '');
        const cands = candidatesFrom(cfg.data, url, cfg.headers);
        const data = parseMaybe(resp.data);
        rememberKeys(data);
        rememberKeys(parseMaybe(cfg.data));
        if (!cands.length) return resp;                       // tanpa identitas — diam
        if (!classifyFailure(resp.status, data)) return resp; // struktur sukses — diam
        const plan = getPlan(planKey(cfg.method, url, cfg.data), planLabel(cfg.method, url));
        if (!plan.cands.length) { plan.cands = cands; plan.reqKeys = bodyKeys(cfg.data); }
        if (!plan.base) plan.base = data;
        dbg('axios' + tag + ' penolakan (status ' + resp.status + ') — rencana jalan |', plan.label);
        const served = planServe(plan);
        if (served.parsed != null) {
            resp.status = 200;
            resp.statusText = 'OK';
            resp.data = served.parsed;
        }
        return resp;
    } catch (e) {
        dbg('patchAxiosResp error: ' + (e && e.message));
        return resp;
    }
}
function installAxios(instance, tag) {
    try {
        if (!instance || !instance.interceptors || !instance.interceptors.response) return false;
        instance.interceptors.response.use(function (response) {
            return patchAxiosResp(response, tag);
        }, function (error) {
            try {
                const resp = error && error.response;
                const cfg = (resp && resp.config) || (error && error.config) || {};
                const url = String((cfg.baseURL || '') || '') + String((cfg.url || '') || '');
                if (resp) return patchAxiosResp(resp, tag + '.err');
                const plan = plans.get(planKey(cfg.method, url, cfg.data));
                if (plan && plan.bytes) {
                    dbg('network-error di endpoint dikenal — rencana terakhir disajikan');
                    return {
                        status: 200, statusText: 'OK', headers: {},
                        config: cfg, data: plan.parsed,
                        request: (error && error.request) || null,
                    };
                }
            } catch (e) { dbg('axios err-patch error: ' + (e && e.message)); }
            return Promise.reject(error);
        });
        return true;
    } catch (e) { return false; }
}
try {
    const axios = require('axios');
    installAxios(axios, '/default');
    const realCreate = axios.create.bind(axios);
    const axiosProxy = new Proxy(axios, {
        get(target, prop) {
            if (prop === 'create') {
                return function created(config) {
                    const inst = realCreate(config);
                    installAxios(inst, '/create');
                    return inst;
                };
            }
            return Reflect.get(target, prop, target);
        },
        apply(target, thisArg, args) { return Reflect.apply(target, thisArg, args); },
    });
    try { require.cache[require.resolve('axios')].exports = axiosProxy; } catch (e) {}
    dbg('layer axios aktif');
} catch (e) {
    dbg('axios tidak termuat saat preload: ' + (e && e.message));
}

/* =================== node-fetch layer (kalau terpasang) ================== */

function makeFetchProxy(realFetch, label) {
    return new Proxy(realFetch, {
        apply(target, thisArg, args) {
            const input = args[0];
            const init = args[1] || {};
            let url = '';
            try { url = typeof input === 'string' ? input : (input && input.url) || String(input); }
            catch (e) { url = ''; }
            let cands = [];
            try {
                cands = candidatesFrom(init && init.body, url, init && init.headers);
            } catch (e) {}
            const p = Reflect.apply(target, typeof thisArg === 'undefined' ? globalThis : thisArg, args);
            if (!cands.length) return p;                  // tanpa identitas — pass-through
            const method = String((init && init.method) || 'GET').toUpperCase();
            return Promise.resolve(p).then((res) => {
                try { return fetchMutate(res, method, url, cands, init && init.body); }
                catch (e) { dbg('fetchMutate error: ' + (e && e.message)); return res; }
            });
        },
        get(target, prop) { return Reflect.get(target, prop, target); },
    });
}
function fetchMutate(res, method, url, cands, body) {
    let origText = null;
    try { origText = res.text.bind(res); } catch (e) {}
    if (!origText) return res;

    const origStatus = res.status;
    const statusFail = typeof origStatus === 'number' && origStatus >= 400;
    const plan = getPlan(planKey(method, url, body), planLabel(method, url));
    if (!plan.cands.length && cands.length) {
        plan.cands = cands;
        plan.reqKeys = bodyKeys(body);
    }

    let onceP = null;
    const once = () => (onceP = onceP || (async () => {
        let text = '';
        try { text = await origText(); } catch (e) { return { out: '' }; }
        const data = parseMaybe(text);
        rememberKeys(data);
        if (!data || !classifyFailure(origStatus, data)) return { out: text };  // sukses — utuh
        if (!plan.base) plan.base = data;
        dbg('fetch penolakan (status ' + origStatus + ') — rencana jalan |', plan.label);
        const served = planServe(plan);
        return { out: served.bytes };
    })());

    if (statusFail) {
        try { Object.defineProperty(res, 'ok', { value: true, configurable: true }); } catch (e) {}
        try { Object.defineProperty(res, 'status', { value: 200, configurable: true }); } catch (e) {}
        try { Object.defineProperty(res, 'statusText', { value: 'OK', configurable: true }); } catch (e) {}
        dbg('fetch status ' + origStatus + ' -> 200 |', plan.label);
    }
    try {
        Object.defineProperty(res, 'text', {
            value: async function () { const r = await once(); return r.out; },
            writable: true, configurable: true,
        });
        Object.defineProperty(res, 'json', {
            value: async function () {
                const r = await once();
                try { return JSON.parse(r.out); } catch (e) { return null; }
            },
            writable: true, configurable: true,
        });
    } catch (e) {}
    return res;
}
try {
    const realFetch = globalThis.fetch;
    if (typeof realFetch === 'function') {
        globalThis.fetch = makeFetchProxy(realFetch, 'fetch');
        dbg('layer fetch aktif');
    }
} catch (e) { dbg('fetch wrap gagal: ' + (e && e.message)); }
try {
    const nf = require('node-fetch');
    if (typeof nf === 'function') {
        require.cache[require.resolve('node-fetch')].exports = makeFetchProxy(nf, 'node-fetch');
        dbg('node-fetch dibungkus');
    }
} catch (e) { /* tidak terpasang — tidak masalah */ }

/* = observasi http/https HANYA saat debug (default: tanpa patch sama sekali) */

if (DEBUG_PATH) {
    const tapHttp = (mod, label) => {
        try {
            if (!mod || typeof mod.request !== 'function') return;
            const orig = mod.request;
            mod.request = new Proxy(orig, {
                apply(target, thisArg, args) {
                    try {
                        let host = '', path = '', meth = '';
                        const o = args[0];
                        if (typeof o === 'string' || o instanceof URL) {
                            try { const u = new URL(o); host = u.hostname; path = u.pathname; meth = u.method || ''; } catch (e) {}
                        } else if (o && typeof o === 'object') {
                            host = o.hostname || o.host || ''; path = o.path || ''; meth = o.method || '';
                        }
                        if (host) dbg('[' + label + '] ' + meth + ' ' + host + String(path).slice(0, 80));
                    } catch (e) {}
                    return Reflect.apply(target, thisArg, args);
                },
                get(t, prop) { return Reflect.get(t, prop, t); },
            });
        } catch (e) {}
    };
    try { tapHttp(require('http'), 'http'); } catch (e) {}
    try { tapHttp(require('https'), 'https'); } catch (e) {}
}

/* ======================= survival (generik, opsional) ==================== */

if (!NO_SURVIVAL) {
    try {
        const realKill = process.kill.bind(process);
        process.kill = disguise(function kill(pid, sig) {
            try {
                const self = pid === process.pid || pid === 0 || pid === -process.pid;
                const hard = sig === 'SIGKILL' || sig === 9 || sig === 'SIGTERM' || sig === 15;
                if (self && hard) {
                    deathSignalAt = Date.now();
                    reopenLockedPlans();
                    say('self-kill(' + String(sig) + ') di-fake — proses dipertahankan');
                    dbg('self-kill(' + String(sig) + ') di-fake + rencana dibuka ulang');
                    return 0;
                }
            } catch (e) {}
            return realKill(pid, sig);
        }, 'kill');
    } catch (e) {}
}
try {
    const realExit = process.exit.bind(process);
    process.exit = disguise(function exit(code) {
        dbg('process.exit(' + code + ') dicegat' + (HOLD_EXIT && code > 0 ? ' — dibekukan' : ''));
        say('process.exit(' + code + ') dicegat' + (HOLD_EXIT && code > 0 ? ' — dibekukan (GHOST_HOLD)' : ''));
        if (code > 0) { deathSignalAt = Date.now(); reopenLockedPlans(); }
        if (HOLD_EXIT && code > 0) {
            const t = setInterval(() => {}, 1 << 30);
            return t;
        }
        return realExit(code);
    }, 'exit');
} catch (e) {}

dbg('=== GHOST v2 aktif — bebas kamus, adaptif prilaku, jejak minimal ===');
say('GHOST v2 aktif (silent mode; GHOST_DEBUG untuk melihat kerjanya)');

/* =================== jejak terakhir: module menghapus dirinya ============ */

try { delete require.cache[__filename]; } catch (e) {}
try {
    const m = require.main;
    if (m && Array.isArray(m.children)) {
        const i = m.children.indexOf(module);
        if (i >= 0) m.children.splice(i, 1);
    }
} catch (e) {}

})();
